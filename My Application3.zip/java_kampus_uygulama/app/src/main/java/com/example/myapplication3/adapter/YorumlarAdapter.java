package com.example.myapplication3.adapter;

public class YorumlarAdapter {
}
