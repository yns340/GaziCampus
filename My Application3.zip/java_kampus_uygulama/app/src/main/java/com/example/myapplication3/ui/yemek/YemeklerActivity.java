package com.example.myapplication3.ui.yemek;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.ViewPager;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import com.example.myapplication3.R;
import com.example.myapplication3.adapter.YemekPagerAdapter;
import com.example.myapplication3.model.Yemek;
import com.google.android.material.tabs.TabLayout;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import java.util.ArrayList;
import java.util.List;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

public class YemeklerActivity extends AppCompatActivity {

    private static final String TAG = "YemeklerActivity";
    private ViewPager viewPager;
    private TabLayout tabLayout;
    private ProgressBar progressBar;
    private YemekPagerAdapter pagerAdapter;
    private List<Yemek> yemekListesi;
    private RatingBar ratingBar;
    private TextView averageRatingTextView;
    private EditText yorumEditText;
    private Button yorumGonderButton;
    private RecyclerView yorumlarRecyclerView;
    private FirebaseDatabase firebaseDatabase;
    private DatabaseReference yorumlarReference;
    private DatabaseReference puanlarReference;
    private int currentYemekPosition = 0;
    private boolean kullaniciPuanVerdi = false;
    private String yemekTarih;
    private FirebaseAuth mAuth;
    private FirebaseUser currentUser;
    private YorumlarAdapter yorumlarAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d(TAG, "onCreate: YemeklerActivity oluşturuldu.");
        setContentView(R.layout.activity_yemekler);

        // UI öğelerini başlat
        viewPager = findViewById(R.id.viewPager);
        tabLayout = findViewById(R.id.tabLayout);
        progressBar = findViewById(R.id.progressBar);
        ratingBar = findViewById(R.id.ratingBar);
        averageRatingTextView = findViewById(R.id.averageRatingTextView);
        yorumEditText = findViewById(R.id.commentEditText);
        yorumGonderButton = findViewById(R.id.addCommentButton);
        yorumlarRecyclerView = findViewById(R.id.commentsRecyclerView);

        // Firebase veritabanını başlat
        firebaseDatabase = FirebaseDatabase.getInstance();
        mAuth = FirebaseAuth.getInstance();
        currentUser = mAuth.getCurrentUser();


        // Manuel olarak yemek listesini oluştur
        yemekListesi = new ArrayList<>();
        yemekListesi.add(new Yemek("06 Mayıs 2025", "Çorba, Tavuk Sote, Pilav, Salata"));
        yemekListesi.add(new Yemek("07 Mayıs 2025", "Çorba, Tavuk Sote, Pilav, Salata"));
        yemekListesi.add(new Yemek("08 Mayıs 2025", "Çorba, Tavuk Sote, Pilav, Salata"));
        yemekListesi.add(new Yemek("09 Mayıs 2025", "Mercimek Çorbası, Köfte, Makarna, Ayran"));
        yemekListesi.add(new Yemek("10 Mayıs 2025", "Domates Çorbası, Izgara Balık, Brokoli, Yoğurt"));
        yemekListesi.add(new Yemek("11 Mayıs 2025", "Ezogelin Çorbası, Mantarlı Tavuk, Bulgur Pilavı, Cacık"));
        yemekListesi.add(new Yemek("12 Mayıs 2025", "Sebze Çorbası, Kıymalı Börek, Salata"));

        // ViewPager'ı ve TabLayout'u kur
        setupViewPager();
        progressBar.setVisibility(View.GONE);

        // Yorumlar RecyclerView'ini ayarla
        yorumlarRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        yorumlarAdapter = new YorumlarAdapter(this, new ArrayList<>());
        yorumlarRecyclerView.setAdapter(yorumlarAdapter);

        // İlk yüklemede ortalama puanı göster ve yorumları yükle
        yemekTarih = yemekListesi.get(0).getTarih();
        displayAverageRating(yemekTarih);
        loadYorumlar(yemekTarih);

        // ViewPager sayfa değiştirme listener'ı
        viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
                //Bu metodun içinde bir şey yapmamıza gerek yok.
            }

            @Override
            public void onPageSelected(int position) {
                // Sayfa değiştiğinde ortalama puanı ve yorumları güncelle
                currentYemekPosition = position;
                yemekTarih = yemekListesi.get(position).getTarih();
                displayAverageRating(yemekTarih);
                loadYorumlar(yemekTarih);
                ratingBar.setRating(0);
                kullaniciPuanVerdi = false;
            }

            @Override
            public void onPageScrollStateChanged(int state) {
                // Bu metodun içinde bir şey yapmamıza gerek yok.
            }
        });

        // RatingBar listener'ı ekle
        ratingBar.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                if (fromUser) {
                    // Kullanıcı tarafından bir değişiklik yapıldıysa
                    // Kullanıcı giriş yapmış olsun veya olmasın, puanı kaydetmeye çalış
                    yemekTarih = yemekListesi.get(currentYemekPosition).getTarih();
                    LocalDate yemekTarihi = LocalDate.parse(yemekTarih, DateTimeFormatter.ofPattern("dd MMMMmapstruct", new Locale("tr", "TR")));
                    LocalDate bugun = LocalDate.now();

                    if (yemekTarihi.isBefore(bugun) || yemekTarihi.isEqual(bugun)) {
                        // Geçmiş veya bugünse puanı kaydet veya güncelle
                        saveRating(yemekTarih, rating);
                        displayAverageRating(yemekTarih);
                        kullaniciPuanVerdi = true;
                    } else {
                        // Gelecek bir tarihse hata mesajı
                        Toast.makeText(YemeklerActivity.this, "Gelecek yemekler için puanlama yapılamaz.", Toast.LENGTH_SHORT).show();
                        ratingBar.setRating(0);
                    }
                }
            }
        });

        // Yorum gönderme listener'ı
        yorumGonderButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Kullanıcı giriş yapmış olsun veya olmasın, yorumu göndermeye çalış
                String yorum = yorumEditText.getText().toString().trim();
                if (!yorum.isEmpty()) {
                    yemekTarih = yemekListesi.get(currentYemekPosition).getTarih();
                    yorumGonder(yemekTarih, yorum);
                    yorumEditText.getText().clear();
                } else {
                    Toast.makeText(YemeklerActivity.this, "Yorumunuzu girin.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void setupViewPager() {
        FragmentManager fragmentManager = getSupportFragmentManager();
        pagerAdapter = new YemekPagerAdapter(fragmentManager, yemekListesi);
        viewPager.setAdapter(pagerAdapter);
        tabLayout.setupWithViewPager(viewPager);
        Log.d(TAG, "setupViewPager: ViewPager ve TabLayout ayarlandı.");
    }

    private void saveRating(String yemekTarih, float rating) {
        puanlarReference = firebaseDatabase.getReference("puanlar");
        String userId = (currentUser != null) ? currentUser.getUid() : "anonim";  // Kullanıcı ID'sini al, null ise "anonim" kullan
        puanlarReference.child(yemekTarih).child(userId).setValue(rating);
        Log.d(TAG, "saveRating: Puan kaydedildi. Tarih: " + yemekTarih + ", Puan: " + rating + ", Kullanıcı: " + userId);
    }

    private void displayAverageRating(String yemekTarih) {
        puanlarReference = firebaseDatabase.getReference("puanlar");
        puanlarReference.child(yemekTarih).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                float total = 0;
                int count = 0;
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    Double puanObj = snapshot.getValue(Double.class);
                    if (puanObj != null) {
                        float puan = puanObj.floatValue();
                        total += puan;
                        count++;
                    }
                }
                float average = count > 0 ? total / count : 0;
                averageRatingTextView.setText("Ortalama Puan: " + String.format("%.1f", average));
                Log.d(TAG, "displayAverageRating: Ortalama Puan: " + average + ", Puan Sayısı: " + count + ", Tarih: " + yemekTarih);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.e(TAG, "displayAverageRating: Veritabanı hatası: " + databaseError.getMessage());
                Toast.makeText(YemeklerActivity.this, "Puanlar alınamadı: " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
                averageRatingTextView.setText("Ortalama Puan: 0");
            }
        });
    }

    private void yorumGonder(String yemekTarih, String yorum) {
        yorumlarReference = firebaseDatabase.getReference("yorumlar");
        String userId = (currentUser != null) ? currentUser.getUid() : "anonim"; // Kullanıcı ID'sini al, null ise "anonim" kullan
        Yorum yeniYorum = new Yorum(userId, yorum);
        yorumlarReference.child(yemekTarih).push().setValue(yeniYorum);
        loadYorumlar(yemekTarih);
    }

    private void loadYorumlar(String yemekTarih) {
        yorumlarReference = firebaseDatabase.getReference("yorumlar").child(yemekTarih);
        yorumlarReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                ArrayList<Yorum> yorumlar = new ArrayList<>();
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    Yorum yorumObj = snapshot.getValue(Yorum.class);
                    if (yorumObj != null) {
                        yorumlar.add(yorumObj);
                    }
                }
                yorumlarAdapter.setYorumlar(yorumlar);
                yorumlarAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.e(TAG, "loadYorumlar: Yorumlar alınamadı: " + databaseError.getMessage());
                Toast.makeText(YemeklerActivity.this, "Yorumlar alınamadı: " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    public static class Yorum {
        private String kullaniciId;
        private String yorum;

        public Yorum() {
            // Boş yapıcı metot Firebase için gerekli
        }

        public Yorum(String kullaniciId, String yorum) {
            this.kullaniciId = kullaniciId;
            this.yorum = yorum;
        }

        public String getKullaniciId() {
            return kullaniciId;
        }

        public String getYorum() {
            return yorum;
        }
    }

    // Yorumları göstermek için RecyclerView Adapter'ı
    private class YorumlarAdapter extends RecyclerView.Adapter<YorumlarAdapter.YorumViewHolder> {

        private List<Yorum> yorumlar;
        private android.content.Context context;

        public YorumlarAdapter(android.content.Context context, List<Yorum> yorumlar) {
            this.context = context;
            this.yorumlar = yorumlar;
        }

        public void setYorumlar(List<Yorum> yeniYorumlar) {
            this.yorumlar = yeniYorumlar;
        }

        @NonNull
        @Override
        public YorumViewHolder onCreateViewHolder(@NonNull android.view.ViewGroup parent, int viewType) {
            // Yorum öğesi için layout'u oluştur
            View view = android.view.LayoutInflater.from(parent.getContext()).inflate(R.layout.yorum_item, parent, false);
            return new YorumViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull YorumViewHolder holder, int position) {
            // Yorum verilerini ViewHolder'a bağla
            Yorum yorum = yorumlar.get(position);
            // holder.kullaniciAdiTextView.setText(yorum.getKullaniciAdi() + ": "); // Kullanıcı adını gösterme
            holder.yorumTextView.setText(yorum.getYorum());
        }

        @Override
        public int getItemCount() {
            return yorumlar.size();
        }

        public class YorumViewHolder extends RecyclerView.ViewHolder {
            TextView yorumTextView;

            public YorumViewHolder(@NonNull View itemView) {
                super(itemView);
                yorumTextView = itemView.findViewById(R.id.yorumTextView);
            }
        }
    }
}

