package com.example.myapplication3.ui.yemek;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class YemeklerDatabaseHelper extends SQLiteOpenHelper {

    private static final String TAG = "YemeklerDBHelper";
    private static final String DATABASE_NAME = "YemeklerDB";
    private static final int DATABASE_VERSION = 1;

    // Puanlar tablosunun adını ve sütunlarını tanımlayın
    public static final String TABLE_PUANLAR = "puanlar";
    public static final String COLUMN_YEMEK_TARIH = "yemek_tarih";
    public static final String COLUMN_RATING = "puan";

    // Puanlar tablosunu oluşturmak için SQL sorgusu
    private static final String SQL_CREATE_PUANLAR_TABLE =
            "CREATE TABLE " + TABLE_PUANLAR + " (" +
                    COLUMN_YEMEK_TARIH + " TEXT PRIMARY KEY, " + // Yemek tarihi birincil anahtar
                    COLUMN_RATING + " REAL NOT NULL);";       // Puan ondalıklı sayı

    public YemeklerDatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Veritabanı oluşturulduğunda puanlar tablosunu oluştur
        db.execSQL(SQL_CREATE_PUANLAR_TABLE);
        Log.d(TAG, "onCreate: Veritabanı ve puanlar tablosu oluşturuldu.");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Veritabanı sürümü yükseltildiğinde (gerekirse) tabloyu güncelleyebilir veya silebilirsiniz
        // Bu örnekte, sadece log kaydı bırakıyoruz
        Log.w(TAG, "onUpgrade: Veritabanı sürümü " + oldVersion + " dan " + newVersion + " ye yükseltildi.");
        // Verileri kaybetmek istemiyorsanız burayı değiştirmeyin
        // db.execSQL("DROP TABLE IF EXISTS " + TABLE_PUANLAR);
        // onCreate(db);
    }
}