package com.example.myapplication3.model;

public class Yorum {
    private String kullaniciAdi;
    private String yorumMetni;
    private int puan;

    public Yorum(String kullaniciAdi, String yorumMetni, int puan) {
        this.kullaniciAdi = kullaniciAdi;
        this.yorumMetni = yorumMetni;
        this.puan = puan;
    }

    // Getter ve Setter metotları
    public String getKullaniciAdi() {
        return kullaniciAdi;
    }

    public void setKullaniciAdi(String kullaniciAdi) {
        this.kullaniciAdi = kullaniciAdi;
    }

    public String getYorumMetni() {
        return yorumMetni;
    }

    public void setYorumMetni(String yorumMetni) {
        this.yorumMetni = yorumMetni;
    }

    public int getPuan() {
        return puan;
    }

    public void setPuan(int puan) {
        this.puan = puan;
    }
}
